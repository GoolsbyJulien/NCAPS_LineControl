add("Person 1");
add("Person 2")
add("Person 3")
add(localStorage.name);

function add(name) {

  var ul = document.getElementById("list");
  var li = document.createElement('li');

  var para = document.createElement("p"); // Create a <p> node
  var h3 = document.createElement("h3"); // Create a <p> node
  var b1 = document.createElement("button");
  var b2 = document.createElement("button");
  var b3 = document.createElement("button");

  var remove = document.createAttribute("class"); // Create a "class" attribute

  remove.value = "remove";
  b1.appendChild(document.createTextNode("Start"));
  b2.appendChild(document.createTextNode("Move-up"));
  b3.appendChild(document.createTextNode("remove"));
  h3.appendChild(document.createTextNode(name + " "));


  // Create a text node
  para.appendChild(document.createTextNode(" 20:00")); // Append the text to <p>
  var att = document.createAttribute("class"); // Create a "class" attribute
  att.value = "person"; // Set the value of the class attribute
  var att2 = document.createAttribute("style"); // Create a "class" attribute
  att2.value = "padding-right: 3px;";

  h3.setAttributeNode(att2);
  li.appendChild(h3);
  li.appendChild(para);
  li.appendChild(b1);
  li.appendChild(b2);
  li.appendChild(b3);
  ul.appendChild(li);
  li.setAttributeNode(att);
  b3.setAttributeNode(remove);

}